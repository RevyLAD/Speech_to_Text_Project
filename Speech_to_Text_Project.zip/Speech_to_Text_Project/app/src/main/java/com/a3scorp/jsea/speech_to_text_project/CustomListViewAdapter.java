package com.a3scorp.jsea.speech_to_text_project;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class CustomListViewAdapter extends BaseAdapter {

    Context con;
    LayoutInflater inflater;
    ArrayList<CustomListView> arrayList;
    int layout;
    TextToSpeech tts;


    public CustomListViewAdapter(Context context, int alayout, ArrayList<CustomListView> arrayList1) {
        con = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        arrayList = arrayList1;
        layout = alayout;

    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return arrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null)
        {
            view = inflater.inflate(layout, viewGroup, false);
        }

        TextView comtitle = (TextView)view.findViewById(R.id.comTitle);
        comtitle.setText(arrayList.get(i).comTitle);

        TextView comText = (TextView)view.findViewById(R.id.comText);
        comText.setText(arrayList.get(i).comText);

        TextView myTitle = (TextView)view.findViewById(R.id.myTitle);
        myTitle.setText(arrayList.get(i).myTitle);

        TextView myText = (TextView)view.findViewById(R.id.myText);
        myText.setText(arrayList.get(i).myText);




        return view;
    }
}

class CustomListView
{
    String comTitle;
    String comText;

    String myTitle;
    String myText;
    CustomListView(String a, String a2, String b, String b2)
    {
        comTitle = a;
        comText = a2;
        myTitle = b;
        myText = b2;
    }
}